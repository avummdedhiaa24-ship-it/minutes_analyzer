# AeroTask — Cross-Platform OS-Level System Monitor

AeroTask is a premium, real-time, lightweight system and process monitor built for both **macOS** and **Linux**. It collects native OS-level metrics (CPU breakdown, memory pressure, disk I/O, network bandwidth, and active processes) directly from kernel sources, serving them through an interactive web-based dashboard.

---

## 🚀 Key Features

- **Real-Time Dashboards**: Smoothly updated charts showing CPU usage, Memory distribution, Disk I/O, and Network rate.
- **Process Management**: Search, sort, and manage running tasks. Terminate/kill processes directly from the UI.
- **OS Integration**:
  - Open executable file locations (calls Finder on macOS, and native File Managers via DBus or `xdg-open` on Linux).
  - Accurate core detection, GPU chip model lookup, and host specs.
- **Platform-Native Collection**: Runs lightweight query operations on macOS and reads direct `/proc` interfaces on Linux (uses 0% background overhead).

---

## 🛠️ How It Works (Under the Hood)

AeroTask queries native operating system APIs dynamically based on the host runtime:

| Metric | macOS Native Source | Linux Native Source |
| :--- | :--- | :--- |
| **CPU Stats** | `top -l 2 -s 1 -n 0` | `/proc/stat` delta calculations |
| **Memory** | `vm_stat` (wired, active, inactive, compressed) | `/proc/meminfo` page mapping |
| **Disk I/O** | `ioreg` block storage statistics | `/proc/diskstats` sector deltas |
| **Network** | `netstat` interface statistics | `/proc/net/dev` interface parsing |
| **Processes** | `ps -A -o pid,ppid,user,state,%cpu,%mem,rss,vsz,comm` | `ps -A -o pid,ppid,user,state,%cpu,%mem,rss,vsz,command` |

---

## ⚙️ Requirements & Installation

AeroTask has **zero external package dependencies** other than Express for serving the static files and API endpoints.

### Setup

1. **Install Node.js** (v16+) on the host system.
2. **Clone and Install**:
   ```bash
   git clone https://github.com/avummdedhiaa24-ship-it/task_manager.git
   cd task_manager
   npm install
   ```

### Running the App

Start the application on the default port (`3000`):
```bash
npm start
```

Or configure a custom port using the `PORT` environment variable:
```bash
PORT=3001 npm start
```

Once started, navigate to **`http://localhost:3000`** (or your custom port) in your web browser.

---

## 📡 API Reference

AeroTask exposes simple REST endpoints to consume system telemetry:

- **`GET /api/sysinfo`**
  Returns static host specs (CPU model, core topology, total RAM, OS name/version, and GPU specs).
- **`GET /api/stats`**
  Returns real-time metrics for CPU usage, memory layout, Disk read/write rates, Network bandwidth, Load average, and Uptime.
- **`GET /api/processes`**
  Returns the complete list of processes containing user, states, CPU%, memory usage (RSS), and parent paths.
- **`POST /api/kill`**
  Terminates a process by PID (payload: `{ "pid": 1234 }`).
- **`POST /api/reveal`**
  Opens the process directory in Finder or native Linux File Manager (payload: `{ "path": "/path/to/exe" }`).
