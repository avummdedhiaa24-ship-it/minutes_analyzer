/**
 * AeroTask — OS-Level Frontend
 *
 * Fetches from three backend endpoints:
 *   /api/sysinfo   — CPU model, cores, RAM, GPU, OS version, hostname
 *   /api/stats     — CPU (user/sys/idle), Memory (full breakdown),
 *                    Disk (read/write bytes/sec), Network (in/out bytes/sec),
 *                    load average, uptime
 *   /api/processes — Enhanced process list with user, state, PPID, VSZ
 */

// ─────────────────────────────────────────────────────────────────────────────
// Application State
// ─────────────────────────────────────────────────────────────────────────────
const HISTORY_POINTS = 40;

const state = {
  processes:   [],
  stats:       null,
  activeTab:   'all',
  searchQuery: '',
  sortBy:      'cpu',
  sortOrder:   'desc',
  refreshRate: 2000,
  killTarget:  null,
  pollTimer:   null,
  osName:      '',
  fileManagerName: 'Finder',

  // Chart histories (0–100 scale)
  cpuHistory:  Array(HISTORY_POINTS).fill(0),
  ramHistory:  Array(HISTORY_POINTS).fill(0),
  diskHistory: Array(HISTORY_POINTS).fill(0),
  netHistory:  Array(HISTORY_POINTS).fill(0),

  // Peak values used to normalize disk/net to 0–100%
  diskPeak: 1,
  netPeak:  1
};

// ─────────────────────────────────────────────────────────────────────────────
// DOM Element Cache
// ─────────────────────────────────────────────────────────────────────────────
const els = {
  // Sidebar
  sysCpuModel: document.getElementById('sys-cpu-model'),
  sysCores:    document.getElementById('sys-cores'),
  sysRam:      document.getElementById('sys-ram'),
  sysGpu:      document.getElementById('sys-gpu'),
  sysHostname: document.getElementById('sys-hostname'),
  sysPlatform: document.getElementById('sys-platform'),
  sysArch:     document.getElementById('sys-arch'),
  sysUptime:   document.getElementById('sys-uptime'),
  sysLoad:     document.getElementById('sys-load'),
  refreshRate: document.getElementById('refresh-rate'),

  // CPU Card
  cpuValue:   document.getElementById('cpu-value'),
  cpuBadge:   document.getElementById('cpu-badge'),
  cpuUserVal: document.getElementById('cpu-user-val'),
  cpuSysVal:  document.getElementById('cpu-sys-val'),
  cpuIdleVal: document.getElementById('cpu-idle-val'),
  cpuUserSeg: document.getElementById('cpu-user-seg'),
  cpuSysSeg:  document.getElementById('cpu-sys-seg'),

  // Memory Card
  ramValue:          document.getElementById('ram-value'),
  ramSub:            document.getElementById('ram-sub'),
  ramBadge:          document.getElementById('ram-badge'),
  memWiredSeg:       document.getElementById('mem-wired-seg'),
  memActiveSeg:      document.getElementById('mem-active-seg'),
  memInactiveSeg:    document.getElementById('mem-inactive-seg'),
  memCompressedSeg:  document.getElementById('mem-compressed-seg'),
  memWiredVal:       document.getElementById('mem-wired-val'),
  memActiveVal:      document.getElementById('mem-active-val'),
  memInactiveVal:    document.getElementById('mem-inactive-val'),
  memCompressedVal:  document.getElementById('mem-compressed-val'),

  // Disk Card
  diskReadVal:  document.getElementById('disk-read-val'),
  diskWriteVal: document.getElementById('disk-write-val'),
  diskReadSeg:  document.getElementById('disk-read-seg'),
  diskWriteSeg: document.getElementById('disk-write-seg'),

  // Network Card
  netInVal:  document.getElementById('net-in-val'),
  netOutVal: document.getElementById('net-out-val'),
  netInSeg:  document.getElementById('net-in-seg'),
  netOutSeg: document.getElementById('net-out-seg'),

  // Process Card
  totalProcesses:     document.getElementById('total-processes'),
  processesBreakdown: document.getElementById('processes-breakdown'),
  appsProgressSeg:    document.getElementById('apps-progress-seg'),
  systemProgressSeg:  document.getElementById('system-progress-seg'),
  procStateSummary:   document.getElementById('proc-state-summary'),

  // Tabs / badges
  badgeAll:    document.getElementById('badge-all'),
  badgeApps:   document.getElementById('badge-apps'),
  badgeSystem: document.getElementById('badge-system'),

  // Table
  searchBox:   document.getElementById('search-box'),
  processList: document.getElementById('process-list'),
  tabBtns:     document.querySelectorAll('.tab-btn'),
  sortHeaders: document.querySelectorAll('.process-table th.sortable'),

  // Chart
  cpuChartPath:  document.getElementById('cpu-chart-path'),
  cpuChartArea:  document.getElementById('cpu-chart-area'),
  ramChartPath:  document.getElementById('ram-chart-path'),
  ramChartArea:  document.getElementById('ram-chart-area'),
  diskChartPath: document.getElementById('disk-chart-path'),
  netChartPath:  document.getElementById('net-chart-path'),

  // Modal
  confirmModal:      document.getElementById('confirm-modal'),
  modalProcessName:  document.getElementById('modal-process-name'),
  modalProcessPid:   document.getElementById('modal-process-pid'),
  modalProcessUser:  document.getElementById('modal-process-user'),
  modalProcessPath:  document.getElementById('modal-process-path'),
  modalCancelBtn:    document.getElementById('modal-cancel-btn'),
  modalConfirmBtn:   document.getElementById('modal-confirm-btn'),

  toastContainer: document.getElementById('toast-container')
};

// ─────────────────────────────────────────────────────────────────────────────
// Utility Helpers
// ─────────────────────────────────────────────────────────────────────────────

function formatUptime(seconds) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const parts = [];
  if (d > 0) parts.push(`${d}d`);
  if (h > 0) parts.push(`${h}h`);
  if (m > 0) parts.push(`${m}m`);
  return parts.length > 0 ? parts.join(' ') : '< 1m';
}

/**
 * Format bytes/sec → "12.3 KB/s", "4.5 MB/s", etc.
 */
function formatBytesPerSec(bps) {
  if (bps === 0)            return '0 B/s';
  if (bps < 1024)           return `${bps} B/s`;
  if (bps < 1024 ** 2)     return `${(bps / 1024).toFixed(1)} KB/s`;
  if (bps < 1024 ** 3)     return `${(bps / 1024 ** 2).toFixed(1)} MB/s`;
  return `${(bps / 1024 ** 3).toFixed(2)} GB/s`;
}

/**
 * Format raw bytes to human-readable (used for memory sizes).
 */
function formatBytes(bytes) {
  if (bytes < 1024)          return `${bytes} B`;
  if (bytes < 1024 ** 2)    return `${(bytes / 1024).toFixed(0)} KB`;
  if (bytes < 1024 ** 3)    return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
  return `${(bytes / 1024 ** 3).toFixed(2)} GB`;
}

function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <div class="toast-message">${message}</div>
    <div class="toast-close">&times;</div>
  `;
  els.toastContainer.appendChild(toast);
  setTimeout(() => toast.classList.add('active'), 50);

  const close = () => {
    toast.classList.remove('active');
    setTimeout(() => toast.remove(), 300);
  };
  toast.querySelector('.toast-close').addEventListener('click', close);
  setTimeout(close, 4000);
}

// ─────────────────────────────────────────────────────────────────────────────
// System Info (fetched once on startup)
// ─────────────────────────────────────────────────────────────────────────────
async function fetchSysInfo() {
  try {
    const res  = await fetch('/api/sysinfo');
    if (!res.ok) return;
    const info = await res.json();

    // Store OS specifics
    state.osName = info.osName;
    state.fileManagerName = info.osName.toLowerCase().includes('mac') ? 'Finder' : 'File Manager';
    document.title = `AeroTask • ${info.osName} System Monitor`;
    
    const warningText = document.querySelector('.warning-text');
    if (warningText) {
      warningText.textContent = `Unsaved work will be lost. Killing system processes may destabilize ${info.osName}.`;
    }

    // Trim CPU model for display (remove repetitive "Apple" prefix duplication)
    const cpuShort = info.cpuModel.length > 24
      ? info.cpuModel.replace(/^Apple /, '').replace(/\s+\d+-Core$/, '')
      : info.cpuModel;

    els.sysCpuModel.textContent = info.cpuModel;
    els.sysCpuModel.title       = info.cpuModel;
    els.sysCores.textContent    = `${info.physicalCores}P / ${info.logicalCores}L`;
    els.sysRam.textContent      = `${(info.totalRamBytes / 1024 ** 3).toFixed(0)} GB`;
    els.sysGpu.textContent      = info.gpuModel;
    els.sysGpu.title            = info.gpuModel;
    els.sysHostname.textContent = info.hostname;
    els.sysPlatform.textContent = `${info.osName} ${info.osVersion}`;
  } catch (err) {
    console.warn('Could not fetch sysinfo:', err);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Stats Fetch & Render
// ─────────────────────────────────────────────────────────────────────────────
async function fetchStats() {
  try {
    const res  = await fetch('/api/stats');
    if (!res.ok) throw new Error('Server error');
    const data = await res.json();
    state.stats = data;

    // ── Sidebar metadata ──
    els.sysArch.textContent   = data.arch;
    els.sysUptime.textContent = formatUptime(data.uptime);
    els.sysLoad.textContent   = data.loadAvg.map(v => v.toFixed(2)).join(' • ');

    // ── CPU Card ──
    const { user, sys, idle, usage } = data.cpu;
    els.cpuValue.textContent    = `${usage.toFixed(1)}%`;
    els.cpuUserVal.textContent  = `user ${user.toFixed(1)}%`;
    els.cpuSysVal.textContent   = `sys ${sys.toFixed(1)}%`;
    els.cpuIdleVal.textContent  = `idle ${idle.toFixed(1)}%`;
    els.cpuUserSeg.style.width  = `${user}%`;
    els.cpuSysSeg.style.width   = `${sys}%`;

    if (usage > 80) {
      els.cpuBadge.textContent = 'Critical';
      els.cpuBadge.className   = 'badge danger';
    } else if (usage > 50) {
      els.cpuBadge.textContent = 'High Load';
      els.cpuBadge.className   = 'badge warning';
    } else if (usage > 25) {
      els.cpuBadge.textContent = 'Moderate';
      els.cpuBadge.className   = 'badge warning';
    } else {
      els.cpuBadge.textContent = 'Normal';
      els.cpuBadge.className   = 'badge success';
    }

    // ── Memory Card ──
    const mem = data.memory;
    const usedGB  = (mem.used  / 1024 ** 3).toFixed(2);
    const totalGB = (mem.total / 1024 ** 3).toFixed(2);

    els.ramValue.textContent = `${mem.percent.toFixed(1)}%`;
    els.ramSub.textContent   = `${usedGB} GB / ${totalGB} GB used`;

    // Memory pressure stacked bar (as % of total)
    const toPercent = (bytes) => Math.min(100, (bytes / mem.total) * 100);
    els.memWiredSeg.style.width      = `${toPercent(mem.wired)}%`;
    els.memActiveSeg.style.width     = `${toPercent(mem.active)}%`;
    els.memInactiveSeg.style.width   = `${toPercent(mem.inactive)}%`;
    els.memCompressedSeg.style.width = `${toPercent(mem.compressed)}%`;

    els.memWiredVal.textContent      = formatBytes(mem.wired);
    els.memActiveVal.textContent     = formatBytes(mem.active);
    els.memInactiveVal.textContent   = formatBytes(mem.inactive);
    els.memCompressedVal.textContent = formatBytes(mem.compressed);

    if (mem.percent > 85) {
      els.ramBadge.textContent = 'Critical';
      els.ramBadge.className   = 'badge danger';
    } else if (mem.percent > 65) {
      els.ramBadge.textContent = 'Heavy';
      els.ramBadge.className   = 'badge warning';
    } else {
      els.ramBadge.textContent = 'Normal';
      els.ramBadge.className   = 'badge success';
    }

    // ── Disk I/O Card ──
    const disk = data.disk;
    els.diskReadVal.textContent  = formatBytesPerSec(disk.readBytesPerSec);
    els.diskWriteVal.textContent = formatBytesPerSec(disk.writeBytesPerSec);

    // Normalize disk bar to running peak
    const diskTotal = disk.readBytesPerSec + disk.writeBytesPerSec;
    if (diskTotal > state.diskPeak) state.diskPeak = diskTotal;
    const diskReadPct  = state.diskPeak > 0 ? (disk.readBytesPerSec  / state.diskPeak) * 100 : 0;
    const diskWritePct = state.diskPeak > 0 ? (disk.writeBytesPerSec / state.diskPeak) * 100 : 0;
    els.diskReadSeg.style.width  = `${diskReadPct}%`;
    els.diskWriteSeg.style.width = `${diskWritePct}%`;

    // ── Network Card ──
    const net = data.network;
    els.netInVal.textContent  = formatBytesPerSec(net.inBytesPerSec);
    els.netOutVal.textContent = formatBytesPerSec(net.outBytesPerSec);

    const netTotal = net.inBytesPerSec + net.outBytesPerSec;
    if (netTotal > state.netPeak) state.netPeak = netTotal;
    const netInPct  = state.netPeak > 0 ? (net.inBytesPerSec  / state.netPeak) * 100 : 0;
    const netOutPct = state.netPeak > 0 ? (net.outBytesPerSec / state.netPeak) * 100 : 0;
    els.netInSeg.style.width  = `${netInPct}%`;
    els.netOutSeg.style.width = `${netOutPct}%`;

    // ── Chart history ──
    const diskPct100 = state.diskPeak > 0 ? Math.min(100, (disk.readBytesPerSec / state.diskPeak) * 100) : 0;
    const netPct100  = state.netPeak  > 0 ? Math.min(100, (net.inBytesPerSec   / state.netPeak)  * 100) : 0;

    state.cpuHistory.push(usage);
    state.cpuHistory.shift();
    state.ramHistory.push(mem.percent);
    state.ramHistory.shift();
    state.diskHistory.push(diskPct100);
    state.diskHistory.shift();
    state.netHistory.push(netPct100);
    state.netHistory.shift();

    updateChart();

  } catch (err) {
    console.error('fetchStats error:', err);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SVG Chart
// ─────────────────────────────────────────────────────────────────────────────
function updateChart() {
  const W = 800, H = 160;
  const step = W / (HISTORY_POINTS - 1);

  function buildPath(history) {
    let line = '', area = `M 0 ${H} `;
    for (let i = 0; i < history.length; i++) {
      const x = i * step;
      const y = Math.max(2, H - (history[i] / 100) * (H - 4));
      line  += i === 0 ? `M ${x} ${y} ` : `L ${x} ${y} `;
      area  += `L ${x} ${y} `;
    }
    area += `L ${W} ${H} Z`;
    return { line, area };
  }

  const cpu  = buildPath(state.cpuHistory);
  const ram  = buildPath(state.ramHistory);
  const disk = buildPath(state.diskHistory);
  const net  = buildPath(state.netHistory);

  els.cpuChartPath.setAttribute('d', cpu.line);
  els.cpuChartArea.setAttribute('d', cpu.area);
  els.ramChartPath.setAttribute('d', ram.line);
  els.ramChartArea.setAttribute('d', ram.area);
  els.diskChartPath.setAttribute('d', disk.line);
  els.netChartPath.setAttribute('d', net.line);
}

// ─────────────────────────────────────────────────────────────────────────────
// Process List Fetch & Render
// ─────────────────────────────────────────────────────────────────────────────
async function fetchProcesses() {
  try {
    const res  = await fetch('/api/processes');
    if (!res.ok) throw new Error('Server error');
    state.processes = await res.json();
    renderProcessSection();
  } catch (err) {
    console.error('fetchProcesses error:', err);
  }
}

function renderProcessSection() {
  const procs = state.processes;

  const total  = procs.length;
  const apps   = procs.filter(p => p.isApp).length;
  const system = total - apps;

  // Running / Sleeping / Zombie count
  const running  = procs.filter(p => p.state?.[0] === 'R').length;
  const sleeping = procs.filter(p => ['S', 'I'].includes(p.state?.[0])).length;
  const zombie   = procs.filter(p => p.state?.[0] === 'Z').length;

  els.totalProcesses.textContent     = total;
  els.processesBreakdown.textContent = `${apps} Apps • ${system} System`;
  els.appsProgressSeg.style.width    = total > 0 ? `${(apps   / total) * 100}%` : '0%';
  els.systemProgressSeg.style.width  = total > 0 ? `${(system / total) * 100}%` : '0%';

  els.procStateSummary.innerHTML = `
    <span class="state-mini state-running">${running} Running</span>
    <span class="state-mini state-sleeping">${sleeping} Sleeping</span>
    <span class="state-mini state-zombie">${zombie} Zombie</span>
  `;

  els.badgeAll.textContent    = total;
  els.badgeApps.textContent   = apps;
  els.badgeSystem.textContent = system;

  // Filter by tab
  let filtered = procs;
  if (state.activeTab === 'apps')   filtered = procs.filter(p => p.isApp);
  if (state.activeTab === 'system') filtered = procs.filter(p => !p.isApp);

  // Search filter
  const q = state.searchQuery.toLowerCase().trim();
  if (q) {
    filtered = filtered.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.pid.toString().includes(q) ||
      p.user.toLowerCase().includes(q) ||
      p.path.toLowerCase().includes(q)
    );
  }

  // Sort
  filtered = [...filtered].sort((a, b) => {
    let va = a[state.sortBy];
    let vb = b[state.sortBy];
    if (typeof va === 'string') {
      va = va.toLowerCase();
      vb = vb.toLowerCase();
      if (va < vb) return state.sortOrder === 'asc' ? -1 : 1;
      if (va > vb) return state.sortOrder === 'asc' ?  1 : -1;
      return 0;
    }
    return state.sortOrder === 'asc' ? va - vb : vb - va;
  });

  if (filtered.length === 0) {
    els.processList.innerHTML = `
      <tr><td colspan="10" class="empty-state">
        <span>No processes match your criteria.</span>
      </td></tr>`;
    return;
  }

  const fragment = document.createDocumentFragment();
  filtered.forEach(p => {
    const tr = document.createElement('tr');
    tr.id = `proc-${p.pid}`;

    // CPU colour
    let cpuClass = 'cpu-low';
    if (p.cpu > 50) cpuClass = 'cpu-high';
    else if (p.cpu > 15) cpuClass = 'cpu-medium';

    // Process state badge
    const stateClass = {
      'Running':  'state-badge-run',
      'Sleeping': 'state-badge-sleep',
      'Idle':     'state-badge-idle',
      'Zombie':   'state-badge-zombie',
      'Stopped':  'state-badge-stop'
    }[p.stateFriendly] || 'state-badge-other';

    const avatarIcon  = p.isApp ? '💻' : '⚙️';
    const avatarClass = p.isApp ? 'app-avatar' : 'sys-avatar';

    tr.innerHTML = `
      <td>
        <div class="proc-name-cell">
          <div class="proc-avatar ${avatarClass}">${avatarIcon}</div>
          <span title="${p.name}">${p.name}</span>
        </div>
      </td>
      <td class="text-right pid-cell">${p.pid}</td>
      <td class="pid-cell user-cell">${p.user}</td>
      <td><span class="state-badge ${stateClass}">${p.stateFriendly}</span></td>
      <td class="text-right cpu-cell ${cpuClass}">${p.cpu.toFixed(1)}%</td>
      <td class="text-right pid-cell">${p.memPercent.toFixed(1)}%</td>
      <td class="text-right pid-cell">${p.memoryMb.toFixed(1)} MB</td>
      <td class="text-right pid-cell muted-text">${p.virtualMb > 1024 ? (p.virtualMb / 1024).toFixed(1) + ' GB' : p.virtualMb + ' MB'}</td>
      <td>
        <div class="path-cell" data-path="${p.path}" title="Click to copy: ${p.path}">${p.path}</div>
      </td>
      <td>
        <div class="action-btns">
          <button class="btn-icon btn-reveal" title="Show in ${state.fileManagerName}" data-path="${p.path}">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
            </svg>
          </button>
          <button class="btn-icon btn-kill" title="Force kill" data-pid="${p.pid}" data-name="${p.name}" data-user="${p.user}" data-path="${p.path}">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="3" y="3" width="18" height="18" rx="2"/>
              <line x1="9" y1="9" x2="15" y2="15"/>
              <line x1="15" y1="9" x2="9" y2="15"/>
            </svg>
          </button>
        </div>
      </td>
    `;
    fragment.appendChild(tr);
  });

  els.processList.innerHTML = '';
  els.processList.appendChild(fragment);
  bindTableEvents();
}

// ─────────────────────────────────────────────────────────────────────────────
// Table Event Binding
// ─────────────────────────────────────────────────────────────────────────────
function bindTableEvents() {
  // Copy path on click
  document.querySelectorAll('.path-cell').forEach(cell => {
    cell.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(cell.dataset.path);
        showToast('Path copied to clipboard');
      } catch {
        showToast('Failed to copy path', 'error');
      }
    });
  });

  // Reveal in File Manager
  document.querySelectorAll('.btn-reveal').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      try {
        const res = await fetch('/api/reveal', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ path: btn.dataset.path })
        });
        const result = await res.json();
        if (res.ok && result.success) showToast(`Revealed in ${state.fileManagerName}`);
        else throw new Error(result.error);
      } catch (err) {
        showToast(err.message, 'error');
      }
    });
  });

  // Kill modal trigger
  document.querySelectorAll('.btn-kill').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const pid  = parseInt(btn.dataset.pid);
      const name = btn.dataset.name;
      const user = btn.dataset.user;
      const path = btn.dataset.path;

      state.killTarget = { pid, name, user, path };
      els.modalProcessName.textContent = name;
      els.modalProcessPid.textContent  = pid;
      els.modalProcessUser.textContent = user;
      els.modalProcessPath.textContent = path;
      els.confirmModal.classList.add('active');
    });
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// Kill Execution
// ─────────────────────────────────────────────────────────────────────────────
async function executeKillProcess() {
  if (!state.killTarget) return;
  const { pid, name } = state.killTarget;
  closeModal();

  try {
    const res    = await fetch('/api/kill', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pid })
    });
    const result = await res.json();

    if (res.ok && result.success) {
      showToast(`Terminated "${name}" (PID ${pid})`, 'success');
      fetchProcesses();
    } else {
      throw new Error(result.error || 'Could not terminate process');
    }
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function closeModal() {
  els.confirmModal.classList.remove('active');
  state.killTarget = null;
}

// ─────────────────────────────────────────────────────────────────────────────
// Event Listeners
// ─────────────────────────────────────────────────────────────────────────────
function setupListeners() {
  // Tab switching
  els.tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      els.tabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.activeTab = btn.dataset.tab;
      renderProcessSection();
    });
  });

  // Search with debounce
  let debounce;
  els.searchBox.addEventListener('input', (e) => {
    clearTimeout(debounce);
    debounce = setTimeout(() => {
      state.searchQuery = e.target.value;
      renderProcessSection();
    }, 150);
  });

  // Sortable column headers
  els.sortHeaders.forEach(th => {
    th.addEventListener('click', () => {
      const field = th.dataset.sort;
      if (state.sortBy === field) {
        state.sortOrder = state.sortOrder === 'desc' ? 'asc' : 'desc';
      } else {
        state.sortBy    = field;
        state.sortOrder = 'desc';
      }

      els.sortHeaders.forEach(h => {
        h.classList.remove('active');
        const icon = h.querySelector('.sort-icon');
        if (icon) icon.className = 'sort-icon';
      });
      th.classList.add('active');
      const icon = th.querySelector('.sort-icon');
      if (icon) icon.className = `sort-icon ${state.sortOrder}`;

      renderProcessSection();
    });
  });

  // Refresh rate
  els.refreshRate.addEventListener('change', (e) => {
    clearInterval(state.pollTimer);
    if (e.target.value === 'pause') {
      showToast('Monitoring paused', 'warning');
    } else {
      state.refreshRate = parseInt(e.target.value);
      showToast(`Refreshing every ${state.refreshRate / 1000}s`);
      startPollingLoop();
    }
  });

  // Modal
  els.modalCancelBtn.addEventListener('click', closeModal);
  els.modalConfirmBtn.addEventListener('click', executeKillProcess);
  els.confirmModal.addEventListener('click', (e) => {
    if (e.target === els.confirmModal) closeModal();
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// Polling Loop
// ─────────────────────────────────────────────────────────────────────────────
function startPollingLoop() {
  fetchStats();
  fetchProcesses();
  state.pollTimer = setInterval(() => {
    fetchStats();
    fetchProcesses();
  }, state.refreshRate);
}

// ─────────────────────────────────────────────────────────────────────────────
// Init
// ─────────────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  fetchSysInfo();   // Sidebar hardware info (once)
  setupListeners();
  startPollingLoop();
});
