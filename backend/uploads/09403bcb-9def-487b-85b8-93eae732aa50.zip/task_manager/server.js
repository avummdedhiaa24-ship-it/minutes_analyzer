/**
 * AeroTask — macOS OS-Level System Monitor
 *
 * Uses real macOS native tools instead of Node's limited `os` module:
 *  - CPU:     `top -l 2 -s 1 -n 0`        → real user/sys/idle breakdown
 *  - Memory:  `vm_stat`                    → wired/active/inactive/compressed
 *  - Disk:    `ioreg -c IOBlockStorageDriver` → cumulative read/write bytes
 *  - Network: `netstat -ib`               → cumulative interface bytes
 *  - SysInfo: `sysctl`, `sw_vers`, `scutil` → CPU model, cores, macOS version
 *  - Process: enhanced `ps` w/ user, state, PPID, virtual mem
 */

const express = require('express');
const path = require('path');
const { exec, spawn } = require('child_process');
const os = require('os');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ─────────────────────────────────────────────────────────────────────────────
// In-memory cache — updated by background background pollers (never block API)
// ─────────────────────────────────────────────────────────────────────────────
let cachedCpuStats    = { user: 0, sys: 0, idle: 100, usage: 0 };
let cachedNetworkRate = { inBytesPerSec: 0, outBytesPerSec: 0 };
let cachedDiskRate    = { readBytesPerSec: 0, writeBytesPerSec: 0 };
let cachedSysInfo     = null;

// Delta-calculation state for CPU, network & disk
let lastCpuSnapshot     = null;
let lastNetworkSnapshot = null;
let lastNetworkTime     = Date.now();
let lastDiskSnapshot    = null;
let lastDiskTime        = Date.now();

// ─────────────────────────────────────────────────────────────────────────────
// CPU POLLER  —  `top -l 2 -s 1 -n 0`
//
// `top -l 2` collects 2 log samples; `-s 1` sets 1-second interval between
// them so the SECOND sample is a real 1-second delta (not since-boot average).
// `-n 0` suppresses process listing for speed.
// ─────────────────────────────────────────────────────────────────────────────
function pollCpuStats() {
  const isMac = os.platform() === 'darwin';
  if (isMac) {
    exec('top -l 2 -s 1 -n 0', { timeout: 8000 }, (err, stdout) => {
      if (!err && stdout) {
        // Grab all CPU usage lines; the LAST one is the most recent sample
        const matches = [
          ...stdout.matchAll(
            /CPU usage:\s+([\d.]+)%\s+user,\s+([\d.]+)%\s+sys,\s+([\d.]+)%\s+idle/g
          )
        ];
        const m = matches[matches.length - 1];
        if (m) {
          const user = parseFloat(m[1]);
          const sys  = parseFloat(m[2]);
          const idle = parseFloat(m[3]);
          cachedCpuStats = {
            user,
            sys,
            idle,
            usage: parseFloat((user + sys).toFixed(1))
          };
        }
      }
      // `top` itself took ~1 s; wait another 2 s before next cycle
      setTimeout(pollCpuStats, 2000);
    });
  } else {
    // Linux
    fs.readFile('/proc/stat', 'utf8', (err, data) => {
      if (!err && data) {
        const line = data.split('\n').find(l => l.startsWith('cpu '));
        if (line) {
          const parts = line.trim().split(/\s+/).slice(1).map(Number);
          const userTicks = parts[0] + parts[1]; // user + nice
          const sysTicks  = parts[2] + parts[5] + parts[6]; // system + irq + softirq
          const idleTicks = parts[3] + parts[4]; // idle + iowait
          const totalTicks = parts.reduce((sum, val) => sum + val, 0);

          if (lastCpuSnapshot) {
            const deltaUser = userTicks - lastCpuSnapshot.user;
            const deltaSys  = sysTicks - lastCpuSnapshot.sys;
            const deltaIdle = idleTicks - lastCpuSnapshot.idle;
            const deltaTotal = totalTicks - lastCpuSnapshot.total;

            if (deltaTotal > 0) {
              const userPercent = (deltaUser / deltaTotal) * 100;
              const sysPercent  = (deltaSys / deltaTotal) * 100;
              const idlePercent = (deltaIdle / deltaTotal) * 100;
              cachedCpuStats = {
                user: parseFloat(userPercent.toFixed(1)),
                sys:  parseFloat(sysPercent.toFixed(1)),
                idle: parseFloat(idlePercent.toFixed(1)),
                usage: parseFloat((userPercent + sysPercent).toFixed(1))
              };
            }
          }
          lastCpuSnapshot = { user: userTicks, sys: sysTicks, idle: idleTicks, total: totalTicks };
        }
      }
      setTimeout(pollCpuStats, 2000);
    });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// NETWORK POLLER  —  `netstat -ib`
//
// Reads cumulative bytes per physical interface from the kernel.
// Computes bytes/second against the previous snapshot.
// ─────────────────────────────────────────────────────────────────────────────
function pollNetworkStats() {
  const isMac = os.platform() === 'darwin';
  if (isMac) {
    exec('netstat -ib', { timeout: 3000 }, (err, stdout) => {
      if (!err && stdout) {
        let totalIn = 0, totalOut = 0;
        const lines = stdout.trim().split('\n');

        for (let i = 1; i < lines.length; i++) {
          const parts = lines[i].trim().split(/\s+/);
          if (parts.length < 10) continue;

          const ifName  = parts[0];
          const network = parts[2] || '';

          // Include only physical interface Link# rows (skip lo0 and IP-family rows)
          if (!ifName.startsWith('lo') && network.startsWith('<Link#')) {
            const ibytes = parseInt(parts[6]);
            const obytes = parseInt(parts[9]);
            if (!isNaN(ibytes)) totalIn  += ibytes;
            if (!isNaN(obytes)) totalOut += obytes;
          }
        }

        const now     = Date.now();
        const elapsed = (now - lastNetworkTime) / 1000;

        if (lastNetworkSnapshot && elapsed > 0) {
          cachedNetworkRate = {
            inBytesPerSec:  Math.max(0, Math.round((totalIn  - lastNetworkSnapshot.in)  / elapsed)),
            outBytesPerSec: Math.max(0, Math.round((totalOut - lastNetworkSnapshot.out) / elapsed))
          };
        }
        lastNetworkSnapshot = { in: totalIn, out: totalOut };
        lastNetworkTime     = now;
      }
      setTimeout(pollNetworkStats, 2000);
    });
  } else {
    // Linux
    fs.readFile('/proc/net/dev', 'utf8', (err, data) => {
      if (!err && data) {
        let totalIn = 0, totalOut = 0;
        const lines = data.trim().split('\n');
        for (let i = 2; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;
          const colonIdx = line.indexOf(':');
          if (colonIdx === -1) continue;
          const ifName = line.substring(0, colonIdx).trim();
          if (ifName.startsWith('lo')) continue;
          
          const statsStr = line.substring(colonIdx + 1).trim();
          const stats = statsStr.split(/\s+/);
          if (stats.length >= 9) {
            const ibytes = parseInt(stats[0]);
            const obytes = parseInt(stats[8]);
            if (!isNaN(ibytes)) totalIn += ibytes;
            if (!isNaN(obytes)) totalOut += obytes;
          }
        }
        
        const now = Date.now();
        const elapsed = (now - lastNetworkTime) / 1000;
        if (lastNetworkSnapshot && elapsed > 0) {
          cachedNetworkRate = {
            inBytesPerSec:  Math.max(0, Math.round((totalIn  - lastNetworkSnapshot.in)  / elapsed)),
            outBytesPerSec: Math.max(0, Math.round((totalOut - lastNetworkSnapshot.out) / elapsed))
          };
        }
        lastNetworkSnapshot = { in: totalIn, out: totalOut };
        lastNetworkTime = now;
      }
      setTimeout(pollNetworkStats, 2000);
    });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// DISK I/O POLLER  —  `ioreg -c IOBlockStorageDriver -k Statistics`
//
// Reads cumulative "Bytes (Read)" and "Bytes (Write)" straight from the
// IOKit registry (same source as Activity Monitor's disk graph).
// Computes bytes/second against the previous snapshot.
// ─────────────────────────────────────────────────────────────────────────────
function pollDiskStats() {
  const isMac = os.platform() === 'darwin';
  if (isMac) {
    exec('ioreg -c IOBlockStorageDriver -k Statistics -r -w 0', { timeout: 5000 }, (err, stdout) => {
      if (!err && stdout) {
        let totalRead = 0, totalWrite = 0;

        for (const m of stdout.matchAll(/"Bytes \(Read\)"=(\d+)/g)) {
          totalRead  += parseInt(m[1]) || 0;
        }
        for (const m of stdout.matchAll(/"Bytes \(Write\)"=(\d+)/g)) {
          totalWrite += parseInt(m[1]) || 0;
        }

        const now     = Date.now();
        const elapsed = (now - lastDiskTime) / 1000;

        if (lastDiskSnapshot && elapsed > 0) {
          cachedDiskRate = {
            readBytesPerSec:  Math.max(0, Math.round((totalRead  - lastDiskSnapshot.read)  / elapsed)),
            writeBytesPerSec: Math.max(0, Math.round((totalWrite - lastDiskSnapshot.write) / elapsed))
          };
        }
        lastDiskSnapshot = { read: totalRead, write: totalWrite };
        lastDiskTime     = now;
      }
      setTimeout(pollDiskStats, 2000);
    });
  } else {
    // Linux
    fs.readFile('/proc/diskstats', 'utf8', (err, data) => {
      if (!err && data) {
        let totalReadSectors = 0, totalWriteSectors = 0;
        const lines = data.trim().split('\n');
        
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;
          const parts = line.split(/\s+/);
          if (parts.length < 10) continue;
          
          const devName = parts[2];
          if (/^(sd[a-z]|nvme[0-9]+n[0-9]+|vd[a-z]|hd[a-z]|xvd[a-z])$/.test(devName)) {
            const rSectors = parseInt(parts[5]);
            const wSectors = parseInt(parts[9]);
            if (!isNaN(rSectors)) totalReadSectors += rSectors;
            if (!isNaN(wSectors)) totalWriteSectors += wSectors;
          }
        }
        
        const totalRead = totalReadSectors * 512;
        const totalWrite = totalWriteSectors * 512;
        
        const now = Date.now();
        const elapsed = (now - lastDiskTime) / 1000;
        if (lastDiskSnapshot && elapsed > 0) {
          cachedDiskRate = {
            readBytesPerSec:  Math.max(0, Math.round((totalRead  - lastDiskSnapshot.read)  / elapsed)),
            writeBytesPerSec: Math.max(0, Math.round((totalWrite - lastDiskSnapshot.write) / elapsed))
          };
        }
        lastDiskSnapshot = { read: totalRead, write: totalWrite };
        lastDiskTime = now;
      }
      setTimeout(pollDiskStats, 2000);
    });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// MEMORY  —  `vm_stat`  (called per request, very fast ~5 ms)
//
// Returns the full macOS memory pressure breakdown identical to Activity Monitor:
//   - wired      : kernel + always-resident pages (can't be paged out)
//   - active     : pages in use by running processes
//   - inactive   : pages recently freed but not yet reclaimed
//   - compressed : pages compressed by macOS memory compression
//   - free       : truly available pages
// ─────────────────────────────────────────────────────────────────────────────
function getMemoryStats() {
  return new Promise((resolve) => {
    const isMac = os.platform() === 'darwin';
    if (isMac) {
      exec('vm_stat', { timeout: 3000 }, (err, stdout) => {
        const total = os.totalmem();

        if (err || !stdout) {
          const free = os.freemem();
          return resolve({
            total, free,
            used: total - free,
            active: 0, inactive: 0, wired: 0, compressed: 0,
            percent: parseFloat(((total - free) / total * 100).toFixed(1))
          });
        }

        const pageSizeM = stdout.match(/page size of (\d+) bytes/);
        const pageSize  = pageSizeM ? parseInt(pageSizeM[1]) : 4096;

        const pages = (key) => {
          const safe = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          const m    = stdout.match(new RegExp(safe + ':\\s+(\\d+)'));
          return m ? parseInt(m[1]) * pageSize : 0;
        };

        const freeBytes  = pages('Pages free') + pages('Pages speculative');
        const active     = pages('Pages active');
        const inactive   = pages('Pages inactive');
        const wired      = pages('Pages wired down');
        const compressed = pages('Pages occupied by compressor');
        const used       = total - freeBytes;

        resolve({
          total, free: freeBytes, used,
          active, inactive, wired, compressed,
          percent: parseFloat(((used / total) * 100).toFixed(1))
        });
      });
    } else {
      // Linux
      fs.readFile('/proc/meminfo', 'utf8', (err, data) => {
        const total = os.totalmem();
        if (err || !data) {
          const free = os.freemem();
          return resolve({
            total, free,
            used: total - free,
            active: 0, inactive: 0, wired: 0, compressed: 0,
            percent: parseFloat(((total - free) / total * 100).toFixed(1))
          });
        }

        const meminfo = {};
        data.split('\n').forEach(line => {
          const match = line.match(/^([^:]+):\s+(\d+)\s+kB/);
          if (match) {
            meminfo[match[1]] = parseInt(match[2]) * 1024; // convert to bytes
          }
        });

        const totalBytes = meminfo['MemTotal'] || total;
        const freeBytes = meminfo['MemAvailable'] || (meminfo['MemFree'] + (meminfo['Buffers'] || 0) + (meminfo['Cached'] || 0));
        const usedBytes = totalBytes - freeBytes;
        
        const active = meminfo['Active'] || 0;
        const inactive = meminfo['Inactive'] || 0;
        const compressed = Math.max(0, (meminfo['SwapTotal'] || 0) - (meminfo['SwapFree'] || 0));
        const wired = Math.max(0, totalBytes - freeBytes - active - inactive - compressed);

        resolve({
          total: totalBytes,
          free: freeBytes,
          used: usedBytes,
          active,
          inactive,
          wired,
          compressed,
          percent: parseFloat(((usedBytes / totalBytes) * 100).toFixed(1))
        });
      });
    }
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// SYSTEM INFO  —  sysctl / sw_vers / scutil / system_profiler
// Fetched once at startup and cached for server lifetime.
// ─────────────────────────────────────────────────────────────────────────────
function fetchSysInfo() {
  const run = (cmd) =>
    new Promise((res) =>
      exec(cmd, { timeout: 5000 }, (e, out) => res(e ? '' : out.trim()))
    );

  const isMac = os.platform() === 'darwin';

  if (isMac) {
    return Promise.all([
      run('sysctl -n machdep.cpu.brand_string'),
      run('sysctl -n hw.physicalcpu'),
      run('sysctl -n hw.logicalcpu'),
      run('sysctl -n hw.memsize'),
      run('sw_vers -productVersion'),
      run('sw_vers -productName'),
      run('scutil --get ComputerName'),
      run('system_profiler SPDisplaysDataType 2>/dev/null | grep "Chipset Model:" | head -1')
    ]).then(([cpuModel, physCores, logCores, memSize, osVersion, osName, hostname, gpuLine]) => ({
      cpuModel:      cpuModel || (os.cpus()[0]?.model ?? 'Unknown'),
      physicalCores: parseInt(physCores) || os.cpus().length,
      logicalCores:  parseInt(logCores)  || os.cpus().length,
      totalRamBytes: parseInt(memSize)   || os.totalmem(),
      osVersion:     osVersion || 'Unknown',
      osName:        osName    || 'macOS',
      hostname:      hostname  || os.hostname(),
      gpuModel:      gpuLine ? gpuLine.replace(/\s*Chipset Model:\s*/, '').trim() : 'Integrated'
    }));
  } else {
    // Linux
    return Promise.all([
      Promise.resolve(os.cpus()[0]?.model || 'Unknown CPU'),
      new Promise((resolve) => {
        fs.readFile('/proc/cpuinfo', 'utf8', (err, data) => {
          if (err || !data) return resolve(os.cpus().length);
          const cores = new Set();
          let physId = '0';
          data.split('\n').forEach(line => {
            const parts = line.split(':');
            if (parts.length === 2) {
              const key = parts[0].trim();
              const val = parts[1].trim();
              if (key === 'physical id') physId = val;
              if (key === 'core id') cores.add(`${physId}-${val}`);
            }
          });
          resolve(cores.size > 0 ? cores.size : os.cpus().length);
        });
      }),
      Promise.resolve(os.cpus().length),
      Promise.resolve(os.totalmem()),
      new Promise((resolve) => {
        fs.readFile('/etc/os-release', 'utf8', (err, data) => {
          let name = 'Linux';
          let version = '';
          if (!err && data) {
            const nameMatch = data.match(/^NAME=["']?([^"\n]+)["']?/m);
            const versionMatch = data.match(/^VERSION_ID=["']?([^"\n]+)["']?/m);
            if (nameMatch) name = nameMatch[1];
            if (versionMatch) version = versionMatch[1];
          }
          resolve({ name, version });
        });
      }),
      Promise.resolve(os.hostname()),
      run('lspci 2>/dev/null | grep -i -E "vga|3d|display" | head -n 1')
    ]).then(([cpuModel, physCores, logCores, memSize, osRelease, hostname, gpuLine]) => {
      let gpuModel = 'Integrated';
      if (gpuLine) {
        const colonIndex = gpuLine.indexOf('controller:');
        if (colonIndex !== -1) {
          gpuModel = gpuLine.substring(colonIndex + 11).trim();
        } else {
          const parts = gpuLine.split(':');
          gpuModel = parts[parts.length - 1].trim();
        }
      }
      return {
        cpuModel,
        physicalCores: physCores,
        logicalCores: logCores,
        totalRamBytes: memSize,
        osVersion: osRelease.version || 'Unknown',
        osName: osRelease.name || 'Linux',
        hostname,
        gpuModel
      };
    });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Helper: extract friendly process name from exec path
// ─────────────────────────────────────────────────────────────────────────────
function parseProcessName(execPath) {
  if (!execPath) return 'Unknown';
  const clean    = execPath.trim();
  const appMatch = clean.match(/\/([^/]+)\.app\//);
  if (appMatch) return appMatch[1];
  
  // For Linux command line (which might contain arguments)
  let exe = clean;
  if (clean.startsWith('"')) {
    const nextQuote = clean.indexOf('"', 1);
    if (nextQuote !== -1) {
      exe = clean.substring(1, nextQuote);
    }
  } else if (clean.startsWith("'")) {
    const nextQuote = clean.indexOf("'", 1);
    if (nextQuote !== -1) {
      exe = clean.substring(1, nextQuote);
    }
  } else {
    exe = clean.split(/\s+/)[0];
  }
  
  const parts = exe.split('/');
  return parts[parts.length - 1] || exe;
}

// ─────────────────────────────────────────────────────────────────────────────
// API ROUTES
// ─────────────────────────────────────────────────────────────────────────────

/**
 * GET /api/stats
 * Returns: CPU (user/sys/idle + usage%), Memory (full breakdown),
 *          Disk (read/write bytes/sec), Network (in/out bytes/sec),
 *          load average, uptime, platform, arch.
 */
app.get('/api/stats', async (req, res) => {
  try {
    const memory = await getMemoryStats();
    res.json({
      cpu:     cachedCpuStats,
      memory,
      disk:    cachedDiskRate,
      network: cachedNetworkRate,
      loadAvg: os.loadavg(),
      uptime:  os.uptime(),
      platform: os.platform(),
      arch:    os.arch()
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch system metrics: ' + error.message });
  }
});

/**
 * GET /api/sysinfo
 * Returns: CPU model, core counts, total RAM, macOS version, hostname, GPU.
 * Served from cache — fetched once at startup.
 */
app.get('/api/sysinfo', async (req, res) => {
  try {
    if (!cachedSysInfo) cachedSysInfo = await fetchSysInfo();
    res.json(cachedSysInfo);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch system info: ' + error.message });
  }
});

/**
 * GET /api/processes
 * Enhanced ps: PID, PPID, USER, STATE, %CPU, %MEM, RSS, VSZ, COMM
 */
app.get('/api/processes', (req, res) => {
  const isMac = os.platform() === 'darwin';
  const psCmd = isMac
    ? 'ps -A -o pid,ppid,user,state,%cpu,%mem,rss,vsz,comm'
    : 'ps -A -o pid,ppid,user,state,%cpu,%mem,rss,vsz,command';

  exec(
    psCmd,
    { maxBuffer: 1024 * 1024 * 10 },
    (error, stdout) => {
      if (error) {
        return res.status(500).json({ error: 'Failed to list processes: ' + error.message });
      }

      const STATE_MAP = {
        R: 'Running',
        S: 'Sleeping',
        I: 'Idle',
        Z: 'Zombie',
        T: 'Stopped',
        t: 'Stopped',
        U: 'Uninterruptible',
        D: 'Disk Wait'
      };

      const lines     = stdout.trim().split('\n');
      const processes = [];

      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        // Columns: PID PPID USER STATE %CPU %MEM RSS VSZ COMM/COMMAND
        const match = line.match(
          /^(\d+)\s+(\d+)\s+(\S+)\s+(\S+)\s+([\d.]+)\s+([\d.]+)\s+(\d+)\s+(\d+)\s+(.+)$/
        );
        if (!match) continue;

        const pid        = parseInt(match[1]);
        const ppid       = parseInt(match[2]);
        const user       = match[3];
        const stateRaw   = match[4];
        const cpu        = parseFloat(match[5]);
        const memPercent = parseFloat(match[6]);
        const rssKb      = parseInt(match[7]);
        const vszKb      = parseInt(match[8]);
        const execPath   = match[9];

        const name     = parseProcessName(execPath);
        const stateKey = stateRaw?.[0] || '?';

        let isApp = false;
        if (isMac) {
          isApp = execPath.includes('.app/');
        } else {
          const isSystemPath = /\/(sbin|usr\/sbin|libexec|lib\/systemd)\//.test(execPath);
          const isKernelThread = execPath.startsWith('[');
          const isRoot = user === 'root';
          isApp = !isKernelThread && !isSystemPath && !isRoot;
        }

        processes.push({
          pid,
          ppid,
          user,
          state:         stateRaw,
          stateFriendly: STATE_MAP[stateKey] ?? stateRaw,
          name,
          path:          execPath,
          cpu,
          memPercent,
          memoryMb:      parseFloat((rssKb / 1024).toFixed(1)),
          virtualMb:     parseFloat((vszKb / 1024).toFixed(1)),
          isApp
        });
      }

      // Default sort: CPU descending
      processes.sort((a, b) => b.cpu - a.cpu);
      res.json(processes);
    }
  );
});

/**
 * POST /api/kill  { pid: number }
 * Sends SIGKILL to the specified process.
 */
app.post('/api/kill', (req, res) => {
  const { pid } = req.body;
  if (!pid || isNaN(pid)) {
    return res.status(400).json({ error: 'Invalid or missing process ID (PID)' });
  }
  try {
    process.kill(parseInt(pid), 'SIGKILL');
    res.json({ success: true, message: `Successfully terminated process ${pid}` });
  } catch (error) {
    res.status(500).json({ error: `Could not terminate process ${pid}: ${error.message}` });
  }
});

/**
 * POST /api/reveal  { path: string }
 * Opens Finder and highlights the process's file/bundle.
 */
app.post('/api/reveal', (req, res) => {
  const { path: targetPath } = req.body;
  if (!targetPath) return res.status(400).json({ error: 'Path is required' });

  const isMac = os.platform() === 'darwin';

  if (isMac) {
    // Reveal the .app bundle root, not the internal executable
    let revealPath  = targetPath;
    const appIndex  = targetPath.indexOf('.app/');
    if (appIndex !== -1) revealPath = targetPath.substring(0, appIndex + 4);

    const child = spawn('open', ['-R', revealPath]);

    child.on('error', (err) =>
      res.status(500).json({ error: `Failed to open Finder: ${err.message}` })
    );
    child.stderr.on('data', (data) => console.error(`open -R stderr: ${data}`));
    child.on('close', (code) => {
      if (code === 0) res.json({ success: true, message: `Revealed in Finder: ${revealPath}` });
      else res.status(500).json({ error: `Failed to reveal in Finder (exit code ${code})` });
    });
  } else {
    // Linux
    const absPath = path.resolve(targetPath);
    const fileUrl = `file://${absPath}`;
    
    // Attempt standard Freedesktop DBus show item method
    const dbusCmd = `dbus-send --session --dest=org.freedesktop.FileManager1 --type=method_call /org/freedesktop/FileManager1 org.freedesktop.FileManager1.ShowItems array:string:"${fileUrl}" string:""`;
    
    exec(dbusCmd, { timeout: 3000 }, (error) => {
      if (!error) {
        return res.json({ success: true, message: `Revealed in File Manager: ${absPath}` });
      }
      
      // Fallback: open the parent directory with xdg-open
      const dirPath = path.dirname(absPath);
      const child = spawn('xdg-open', [dirPath]);
      
      child.on('error', (err) =>
        res.status(500).json({ error: `Failed to open File Manager: ${err.message}` })
      );
      child.on('close', (code) => {
        if (code === 0) res.json({ success: true, message: `Opened directory: ${dirPath}` });
        else res.status(500).json({ error: `Failed to open directory (exit code ${code})` });
      });
    });
  }
});

// Fallback: serve SPA for all unmatched routes
app.get('*', (req, res) =>
  res.sendFile(path.join(__dirname, 'public', 'index.html'))
);

// ─────────────────────────────────────────────────────────────────────────────
// STARTUP  —  pre-fetch sysinfo then start background pollers
// ─────────────────────────────────────────────────────────────────────────────
app.listen(PORT, async () => {
  console.log(`\n┌─────────────────────────────────────────────┐`);
  console.log(`│  AeroTask  •  OS-Level macOS Monitor         │`);
  console.log(`│  http://localhost:${PORT}                       │`);
  console.log(`└─────────────────────────────────────────────┘\n`);

  console.log('Fetching system info...');
  cachedSysInfo = await fetchSysInfo();
  console.log(`  CPU    : ${cachedSysInfo.cpuModel}`);
  console.log(`  Cores  : ${cachedSysInfo.physicalCores}P / ${cachedSysInfo.logicalCores}L`);
  console.log(`  RAM    : ${(cachedSysInfo.totalRamBytes / 1024 ** 3).toFixed(0)} GB`);
  console.log(`  OS     : ${cachedSysInfo.osName} ${cachedSysInfo.osVersion}`);
  console.log(`  GPU    : ${cachedSysInfo.gpuModel}`);
  console.log(`  Host   : ${cachedSysInfo.hostname}\n`);

  console.log('Starting background OS metric pollers...');
  pollCpuStats();      // CPU via top   (updates every ~3 s)
  pollNetworkStats();  // Net via netstat (every 2 s)
  pollDiskStats();     // Disk via ioreg (every 2 s)
  console.log('All pollers running.\n');
});
